/*******************************************************************************
 * Obada Alagha cssc2115 819 852 274
 * Amiel Nava   cssc2124 824 264 864
 * CS570 Summer 2020
 * Project:    Assignment #2, msh microshell
 * Filename:   main.c
 * Notes:      Contains the main() method that launches the msh microshell.
 *             WRITTEN BY OBADA.
 ******************************************************************************/

#include "header.h"

int main(int argc, char **argv) {
    /* Call function to start the shell */
    begin_shell(argc);

    return 0;
}
